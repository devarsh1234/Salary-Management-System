# Salary-Management-System
Salary Management is a Java, MySQL based project, the project demonstrates the simplest way to manage employees and assign their salaries with all the required fields in a standard salary pay slip in this project the HR(head Human Resource) can add new employees or remove old ones and assign salaries to the employee or update their salaries with the credentials given by the HR the employee can login to the system and view his salary details and payments made to him by the accountant. The accountant can login as well and view all employees with the salaries and pay their salaries on the payment time. The accountant can also maintain the funds available for the company.


Technologies Used: Java, MySql

Introduction: In this project the main objective is to help in keeping of records for the salaries of each employee with the complete details of their salary breakdown, which includes their main salary and deductions made the project also keeps record for the payments made by the accountant to the employee at the described date of salary payment. There are three modules in this project namely HR module, Accountant Module and Employee module.
